class Player(weapon: String) {
    val playerWeapon = weapon.lowercase()
}